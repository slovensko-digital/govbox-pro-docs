# Notifikácie
-	GovBox Pro ponúka možnosti nastavenia notifikácií upozorňujúcich na nové správy, zmeny vlákna/tagu na správe
-	Možnosti notifikácií môžu zahŕňať upozornenia na prechádzanie vlákien, odpovedanie, skrývanie správ, pridanie a použivanie štítkov