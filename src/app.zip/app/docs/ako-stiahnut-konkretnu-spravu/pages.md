# Ako sťiahnúť konkrétnu správu?
-	Pri zobrazení konkrétnej správy pri predmete sa v vpravom rohu nachádza ikonka s troma zvyslími bodkami
- obrazok
-	Po kliknutí na ikonku s troma bodkami sa zobrazí rozbalovacie okno v ktorej na nachádza možnosť stiahnutia správy
- obrazok
-	Po kliknutí na možnosť stiahnúť správu sa zobrazí vpravom hornom rohu súbor ktorý sa aktuálne sťahuje.
- obrazok