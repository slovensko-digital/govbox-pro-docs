# Zobrazenie všetkých vlákien
-	Po prihlasení do GovBoxu si použivateľ vie pozrieť/zobraziť všetky vlákna ktoré sa v schránke nachádzajú a to kliknutím na „všetky správy“ v ľavom hornom rohu obrazovky
![Alternativny text, ked nie je obrazok](../zobrazenie-vsetkych-vlakien.png "Nazov obrazku")
-	Tak isto po každom kliknutí na tlačidlo „všetky správy“ sa zobrazia všetky vlákna, kde si použivateľ vie otvoriť konkrétnu správu a to kliknutím na ňu.
