# Ako pridať poznámku ku konkrétnemu vláknu?
-	Pri zobrazení konkrétnej správy sa pri názve správy v pravom rohu nachádza ikonka s troma zvyslimi bodkami
![Alternativny text, ked nie je obrazok](../obrázok11.png "Nazov obrazku")
-	Po kliknutí na ikonku s troma bodkami sa zobrazí rozbalovacie okno s možnosťou pridať poznámku
![Alternativny text, ked nie je obrazok](../obrázok12.png "Nazov obrazku")
-	Po kliknutí na pridať poznámku sa pod názvom vlákna zobrazí okno pre písanie ľubovoľnej poznámky k vláknu
![Alternativny text, ked nie je obrazok](../obrázok13.png "Nazov obrazku")
-	Po dopísaní akejkoľvek poznámky je potrebné kliknuť na modré tlačidlo „uložiť“ a novovzniknutá poznámka sa bude zobrazovať vždy pod názvom vlákna
![Alternativny text, ked nie je obrazok](../obrázok14.png "Nazov obrazku")