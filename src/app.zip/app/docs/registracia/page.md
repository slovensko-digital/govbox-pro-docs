# Registrácia
-	Proces vytvorenia nového účtu v elektronickej schránke, čo môže zahŕňať vyplnenie formulára s osobnými údajmi, overenie identity a vytvorenie prístupových údajov.
-	Cez web slovensko.sk si vytvor datovu schranku ( postup najdeš na webe slovensko.sk)
-	K vytvoreniu su potrebné OP s čipom, čítačka OP a BOK heslo
    - Pre podrobnejší popis navštív web slovensko.sk