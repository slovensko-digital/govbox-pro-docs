# Ako zbaliť správu?
   -	Pri zobrazení konkrétnej správy pri predmete sa v vpravom rohu nachádza ikonka s troma zvyslími bodkami
   ![Alternativny text, ked nie je obrazok](../ako-zbalit-spravu.png "Nazov obrazku")
   -	Po kliknutí na ikonku s troma bodkami sa zobrazí rozbalovacie okno v ktorej na nachádza možnosť zbaliť a už nerozbaľovať
   ![Alternativny text, ked nie je obrazok](../ako-zbalit-spravu2.png "Nazov obrazku")
   -	Po kliknutí na možnosť zbaliť a už nerozbaľovať sa konkrétna správa zbalí a použivateľ vidí iba názov kokrétnej správy
   ![Alternativny text, ked nie je obrazok](../ako-zbalit-spravu3.png "Nazov obrazku")


# Ako rozbaliť poštu?
-	Pre opätovné zobrazenie celého obsahu správy musí uživateľ kliknúť na ikonku šipky dole
![Alternativny text, ked nie je obrazok](../ako-rozbalit-postu.png "Nazov obrazku")
-	Po kliknutí na ikonku šipky dole sa zobrazí cely obsah správy
![Alternativny text, ked nie je obrazok](../ako-zbalit-postu2.png "Nazov obrazku")