# Zobrazenie konkretnej správy
-	Po kliknutí na konkretnú správu sa zobrazí jej obsah. Správne zobrazenie prijatej správy pozostáva z:
1.	Názov 
2.	Štítky
3.	Obsah správy s možnosťou odpovedať
4.	Prílohy
![Alternativny text, ked nie je obrazok](../zobrazenie-konkretnej-spravy.png "Nazov obrazku")